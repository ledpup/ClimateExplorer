ACORN-SAT v2.2 station data for 112 sites listed in acorn_sat_v2.2_stations.txt
Australian Bureau of Meteorology 

